# YAD Premium Website Sample

A client-facing static concept for YAD E-Bikes, inspired by premium product storytelling and modern EV/tech brand sites.

## Run
Open `index.html` directly in a browser, or serve the folder with any static web server.

## Important
- This is a **sample concept**, not the final YAD production site.
- Product names, specifications and claims are placeholders.
- Image URLs are remote demo imagery and should be replaced with approved YAD photography/video.
- The design is responsive and optimized for mobile, tablet and desktop.
